import re
from django.shortcuts import render
from .models import Countries
from .models import Customer_info
from .models import Account_info
from .models import Transactions

# Create your views here.
def home(request):
    return render(request,'home.html')

def predict(request):
    ak=request.POST['accountKey'] #CASP_D00630169780104
    temp=Account_info.objects.all().filter(account_key=ak)
    print(len(temp))
    acc_owner = temp[0].primary_partkey #users object
    status=None 
    reason=None
    print(Transactions.objects.filter(acc_key=ak))
    if len(Transactions.objects.filter(acc_key=ak)) > 10:
        status='H1'
        reason='no of transaction is greater than 10'
        return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
    elif len(Transactions.objects.filter(acc_key=ak)) < 10:
        t=Transactions.objects.filter(acc_key=ak).filter(transaction_type='INN')
        t1=Transactions.objects.filter(acc_key=ak).filter(transaction_type='OUT')
        s=0
        for i in t:
            s+=i.transactionamount
        if s>1000 :
            status='H2'
            reason=' sum of incomming transacrtion is greater than 1000'
            return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
        s=0
        for i in t1:
            s+=i.transactionamount
        if s>800:
            status='H3'
            reason='sum of outgoing  transacrtion is greater than 800'
            return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
    elif len(Transactions.objects.filter(acc_key=ak)) > 20:
        status='H4'
        reason='no of transaction is > 20'
        return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
            
    if len(Transactions.objects.filter(acc_key=ak)) > 6:
        status='M1'
        reason='no of transaction is greater than 6'
        return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
    elif len(Transactions.objects.filter(acc_key=ak)) < 6:
        t=Transactions.objects.filter(acc_key=ak).filter(transaction_type='INN')
        t1=Transactions.objects.filter(acc_key=ak).filter(transaction_type='OUT')
        s=0
        for i in t:
            s+=i.transactionamount
        if s>600 and s<1000 :
            status='M2'
            reason='sum of transacrtion is between 600 to 1000'
            return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
        s=0
        for i in t1:
            s+=i.transactionamount
        if s>500 and s<800:
            status='M3'
            reason='sum of transacrtion is between 500 to 800'
            return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
    elif len(Transactions.objects.filter(acc_key=ak)) > 10 and len(Transactions.objects.filter(acc_key=ak))<20:
        status='M4'
        reason='no of transaction is > 10 and < 20'
        return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
    if len(Transactions.objects.filter(acc_key=ak)) < 10:
        status='L1'
        reason='no of transaction is less than 10'
        return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
    elif len(Transactions.objects.filter(acc_key=ak)) > 10:
        t=Transactions.objects.filter(acc_key=ak).filter(transaction_type='INN')
        t1=Transactions.objects.filter(acc_key=ak).filter(transaction_type='OUT')
        s=0
        for i in t:
            s+=i.transactionamount
        if s<600 :
            status='L2'
            reason='sum of incomming transactions is less than 600'
            return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
        s=0
        for i in t1:
            s+=i.transactionamount
        if s<500:
            status='L3'
            reason='sum of outgoing transactions is less than 500'
            return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})
    elif len(Transactions.objects.filter(acc_key=ak)) < 10 :
        status='L4'
        reason='no of transactions is less than 10'
        
    return render(request,'output.html',{'Customer_Name': acc_owner.customer_name ,'Residential_Country': acc_owner.resident_country ,'Risk_Rating':status,'Risk_Rating_Reason':reason})