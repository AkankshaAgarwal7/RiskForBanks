from django.contrib import admin

from .models import Countries
from .models import Customer_info
from .models import Account_info
from .models import Transactions

# Register your models here.
admin.site.register(Countries)
admin.site.register(Customer_info)
admin.site.register(Account_info)
admin.site.register(Transactions)